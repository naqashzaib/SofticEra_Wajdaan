﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class Class1
    {
        private int a;
        private int t;

public Class1()
{
    a = 54;



}
public Class1(int c)
{
    a = c;


}


        public string crmethod()
        {

            return "hello";

        }
        ~Class1()
        {
            


        }


        public  int _t
        {
            get { return t; }
            set
            {
                if (value < 1)
                {
                    throw  new Exception("invalid data");
                }
                else
                {
                    t = value;  
                }
               
            }

        }





    }
}
